var hierarchy =
[
    [ "app\\controllers\\mailController", "classapp_1_1controllers_1_1mailController.html", null ],
    [ "app\\controllers\\recaptcha", "classapp_1_1controllers_1_1recaptcha.html", null ],
    [ "Controller", null, [
      [ "app\\controllers\\adminController", "classapp_1_1controllers_1_1adminController.html", null ],
      [ "app\\controllers\\dashboardController", "classapp_1_1controllers_1_1dashboardController.html", null ],
      [ "app\\controllers\\indexController", "classapp_1_1controllers_1_1indexController.html", null ],
      [ "app\\controllers\\reportController", "classapp_1_1controllers_1_1reportController.html", null ],
      [ "app\\controllers\\userController", "classapp_1_1controllers_1_1userController.html", null ]
    ] ]
];