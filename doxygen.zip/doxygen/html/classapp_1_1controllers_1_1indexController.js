var classapp_1_1controllers_1_1indexController =
[
    [ "index", "classapp_1_1controllers_1_1indexController.html#a4fd45f46ec4f4c4b107b020aaf753752", null ]
];