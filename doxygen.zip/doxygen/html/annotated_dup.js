var annotated_dup =
[
    [ "app", "namespaceapp.html", "namespaceapp" ]
];