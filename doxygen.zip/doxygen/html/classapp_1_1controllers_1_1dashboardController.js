var classapp_1_1controllers_1_1dashboardController =
[
    [ "index", "classapp_1_1controllers_1_1dashboardController.html#a07b8867168bbaae283adebf19990a660", null ],
    [ "invoice", "classapp_1_1controllers_1_1dashboardController.html#afd40a431a9efd213a76f6276cda7debf", null ]
];