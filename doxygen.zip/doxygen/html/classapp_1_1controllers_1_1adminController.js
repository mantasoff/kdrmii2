var classapp_1_1controllers_1_1adminController =
[
    [ "delete", "classapp_1_1controllers_1_1adminController.html#a5153b610b040a896135ae0d4924a0cb6", null ],
    [ "index", "classapp_1_1controllers_1_1adminController.html#a04f354fd0d26bc82b16154a13b51529b", null ],
    [ "login", "classapp_1_1controllers_1_1adminController.html#abbe77fb018ae490b2e5f7f84fe226dbe", null ],
    [ "logout", "classapp_1_1controllers_1_1adminController.html#af9bc0bdb34406837a9015881ea36ceb4", null ],
    [ "update", "classapp_1_1controllers_1_1adminController.html#ae2e7a9b23b4e3e5a68f3f941cf0ada1f", null ]
];