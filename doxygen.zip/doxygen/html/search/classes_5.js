var searchData=
[
  ['usercontroller',['userController',['../classapp_1_1controllers_1_1userController.html',1,'app::controllers']]]
];
