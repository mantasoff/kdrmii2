var searchData=
[
  ['recaptcha',['recaptcha',['../classapp_1_1controllers_1_1recaptcha.html',1,'app::controllers']]],
  ['reportcontroller',['reportController',['../classapp_1_1controllers_1_1reportController.html',1,'app::controllers']]]
];
