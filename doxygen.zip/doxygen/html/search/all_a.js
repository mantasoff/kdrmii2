var searchData=
[
  ['validate',['validate',['../classapp_1_1controllers_1_1userController.html#a42c095d7f8056715e598fc27df1dda68',1,'app::controllers::userController']]],
  ['verify',['verify',['../classapp_1_1controllers_1_1recaptcha.html#a982745d78d7b3cd82413ab846d58ddac',1,'app::controllers::recaptcha']]]
];
