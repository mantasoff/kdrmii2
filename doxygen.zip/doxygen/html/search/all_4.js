var searchData=
[
  ['login',['login',['../classapp_1_1controllers_1_1adminController.html#abbe77fb018ae490b2e5f7f84fe226dbe',1,'app\controllers\adminController\login()'],['../classapp_1_1controllers_1_1userController.html#af3631352c699641e90b5001e901a8bc8',1,'app\controllers\userController\login()']]],
  ['logout',['logout',['../classapp_1_1controllers_1_1adminController.html#af9bc0bdb34406837a9015881ea36ceb4',1,'app\controllers\adminController\logout()'],['../classapp_1_1controllers_1_1userController.html#a2077775eeed4fe206cf56cd926f66fd7',1,'app\controllers\userController\logout()']]]
];
