var searchData=
[
  ['app',['app',['../namespaceapp.html',1,'']]],
  ['controllers',['controllers',['../namespaceapp_1_1controllers.html',1,'app']]]
];
