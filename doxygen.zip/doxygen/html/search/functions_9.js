var searchData=
[
  ['update',['update',['../classapp_1_1controllers_1_1adminController.html#ae2e7a9b23b4e3e5a68f3f941cf0ada1f',1,'app::controllers::adminController']]]
];
