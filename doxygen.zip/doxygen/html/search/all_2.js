var searchData=
[
  ['emailexcel',['emailExcel',['../classapp_1_1controllers_1_1reportController.html#a21181f9646b2289885eb80c319e47f34',1,'app::controllers::reportController']]]
];
