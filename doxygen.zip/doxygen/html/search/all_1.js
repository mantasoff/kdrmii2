var searchData=
[
  ['dashboardcontroller',['dashboardController',['../classapp_1_1controllers_1_1dashboardController.html',1,'app::controllers']]],
  ['delete',['delete',['../classapp_1_1controllers_1_1adminController.html#a5153b610b040a896135ae0d4924a0cb6',1,'app::controllers::adminController']]],
  ['diplomaword',['diplomaWord',['../classapp_1_1controllers_1_1reportController.html#a8b1c54721e90f2467e23f328e1c0168e',1,'app::controllers::reportController']]]
];
