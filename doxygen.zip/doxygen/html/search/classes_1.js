var searchData=
[
  ['dashboardcontroller',['dashboardController',['../classapp_1_1controllers_1_1dashboardController.html',1,'app::controllers']]]
];
