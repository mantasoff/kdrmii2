var searchData=
[
  ['admincontroller',['adminController',['../classapp_1_1controllers_1_1adminController.html',1,'app::controllers']]]
];
