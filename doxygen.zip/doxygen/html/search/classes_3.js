var searchData=
[
  ['mailcontroller',['mailController',['../classapp_1_1controllers_1_1mailController.html',1,'app::controllers']]]
];
