var namespaces_dup =
[
    [ "app", "namespaceapp.html", "namespaceapp" ]
];